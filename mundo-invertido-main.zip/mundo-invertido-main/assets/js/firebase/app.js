  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.9.3/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyBd0tVXbcLVKBRZ7teDArqj_uhEbonAtRc",
    authDomain: "projeto-mundo-invertido-cceb5.firebaseapp.com",
    projectId: "projeto-mundo-invertido-cceb5",
    storageBucket: "projeto-mundo-invertido-cceb5.appspot.com",
    messagingSenderId: "896866034949",
    appId: "1:896866034949:web:4c53dad8c087d95d62036c"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  
  export default app
